// ================= APP STATE & DATABASE CONFIG =================

const DB = {
    get(key, defaultValue = []) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : defaultValue;
    },
    save(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    }
};

// Default Credentials
const USERS = [
    { username: 'teacher', password: 'password', role: 'teacher', name: 'Dr. Sarah Jenkins', branch: 'ALL', year: 'ALL' },
    { username: 'monitor', password: 'password', role: 'monitor', name: 'Class Monitor', branch: 'CSE', year: '3rd Year' }
];

// Initialize Mock Database if empty
function initializeDatabase() {
    // Schema migration: reset storage if old class ID format is detected or if startTime/subject is not present in mock logs
    const oldClasses = localStorage.getItem('classes');
    const oldLogs = localStorage.getItem('attendance');
    if ((oldClasses && oldClasses.includes('10a')) || (oldLogs && (!oldLogs.includes('startTime') || !oldLogs.includes('subject')))) {
        localStorage.clear();
    }

    if (DB.get('classes').length === 0) {
        const mockClasses = [
            { id: 'cse-3rd_year', name: 'CSE - 3rd Year' },
            { id: 'ece-2nd_year', name: 'ECE - 2nd Year' }
        ];
        DB.save('classes', mockClasses);
    }

    if (DB.get('students').length === 0) {
        const mockStudents = [
            // CSE - 3rd Year
            { id: 's1', name: 'Aarav Sharma', classId: 'cse-3rd_year', phone: '+919876543210', whatsapp: '+919876543210' },
            { id: 's2', name: 'Priya Patel', classId: 'cse-3rd_year', phone: '+919876543211', whatsapp: '+919876543211' },
            { id: 's3', name: 'Ishaan Kishen', classId: 'cse-3rd_year', phone: '+919876543212', whatsapp: '+919876543212' },
            { id: 's4', name: 'Ananya Sen', classId: 'cse-3rd_year', phone: '+919876543213', whatsapp: '+919876543213' },
            // ECE - 2nd Year
            { id: 's5', name: 'Kabir Mehta', classId: 'ece-2nd_year', phone: '+919876543214', whatsapp: '+919876543214' },
            { id: 's6', name: 'Diya Joshi', classId: 'ece-2nd_year', phone: '+919876543215', whatsapp: '+919876543215' },
            { id: 's7', name: 'Vivaan Shah', classId: 'ece-2nd_year', phone: '+919876543216', whatsapp: '+919876543216' },
            { id: 's8', name: 'Riya Verma', classId: 'ece-2nd_year', phone: '+919876543217', whatsapp: '+919876543217' }
        ];
        DB.save('students', mockStudents);
    }

    if (DB.get('attendance').length === 0) {
        // Aarav Sharma (s1) absent on 16th and 17th July in CSE - 3rd Year
        // Diya Joshi (s6) absent on 15th, 16th, and 17th July in ECE - 2nd Year
        // Riya Verma (s8) absent on 16th and 17th July in ECE - 2nd Year
        const mockAttendance = [
            // CSE - 3rd Year: July 16
            {
                id: 'log-cse-1',
                classId: 'cse-3rd_year',
                date: '2026-07-16',
                startTime: '09:00',
                endTime: '10:00',
                subject: 'Database Systems (DBMS)',
                topic: 'Introduction to Database Management',
                records: { s1: 'absent', s2: 'present', s3: 'present', s4: 'present' },
                submittedBy: 'monitor'
            },
            // CSE - 3rd Year: July 17
            {
                id: 'log-cse-2',
                classId: 'cse-3rd_year',
                date: '2026-07-17',
                startTime: '09:30',
                endTime: '10:30',
                subject: 'Database Systems (DBMS)',
                topic: 'Relational Algebra & SQL Joins',
                records: { s1: 'absent', s2: 'present', s3: 'present', s4: 'present' },
                submittedBy: 'monitor'
            },
            // ECE - 2nd Year: July 15
            {
                id: 'log-ece-1',
                classId: 'ece-2nd_year',
                date: '2026-07-15',
                startTime: '10:45',
                endTime: '11:45',
                subject: 'Electronic Circuits',
                topic: 'Network Analysis & Circuit Theorem',
                records: { s5: 'present', s6: 'absent', s7: 'present', s8: 'present' },
                submittedBy: 'monitor'
            },
            // ECE - 2nd Year: July 16
            {
                id: 'log-ece-2',
                classId: 'ece-2nd_year',
                date: '2026-07-16',
                startTime: '11:00',
                endTime: '12:00',
                subject: 'Electronic Circuits',
                topic: 'Thevenins & Norton Equivalent Circuits',
                records: { s5: 'present', s6: 'absent', s7: 'present', s8: 'absent' },
                submittedBy: 'monitor'
            },
            // ECE - 2nd Year: July 17
            {
                id: 'log-ece-3',
                classId: 'ece-2nd_year',
                date: '2026-07-17',
                startTime: '11:15',
                endTime: '12:15',
                subject: 'Electronic Circuits',
                topic: 'Maximum Power Transfer Theorem',
                records: { s5: 'present', s6: 'absent', s7: 'present', s8: 'absent' },
                submittedBy: 'monitor'
            }
        ];
        DB.save('attendance', mockAttendance);
    }
}

// ================= NOTIFICATIONS UTILITY =================

function showToast(message, type = 'info') {
    const toast = document.getElementById('notification-toast');
    const msgSpan = document.getElementById('notification-message');
    const iconSpan = document.getElementById('notification-icon');
    
    msgSpan.textContent = message;
    if (type === 'success') {
        iconSpan.textContent = '✅';
        toast.className = 'notification show success';
    } else if (type === 'error') {
        iconSpan.textContent = '❌';
        toast.className = 'notification show error';
    } else {
        iconSpan.textContent = '🔔';
        toast.className = 'notification show';
    }

    setTimeout(() => {
        toast.classList.remove('show');
    }, 4000);
}

// ================= LOGIN & AUTH LOGIC =================

let authMode = 'login'; // 'login' or 'register'

function switchLoginPortal(role) {
    const container = document.getElementById('login-view');
    const subtitle = document.getElementById('portal-subtitle');
    const inputRole = document.getElementById('login-role');
    const registerRole = document.getElementById('register-role');
    const toggleMon = document.getElementById('toggle-monitor');
    const toggleTeach = document.getElementById('toggle-teacher');

    if (inputRole) inputRole.value = role;
    if (registerRole) registerRole.value = role;

    if (role === 'teacher') {
        container.className = 'login-container teacher-mode';
        if (authMode === 'login') {
            subtitle.textContent = 'Access the administrator teacher portal';
        } else {
            subtitle.textContent = 'Create a new administrator teacher account';
        }
        toggleTeach.classList.add('active');
        toggleMon.classList.remove('active');
        toggleTeach.setAttribute('aria-selected', 'true');
        toggleMon.setAttribute('aria-selected', 'false');
    } else {
        container.className = 'login-container monitor-mode';
        if (authMode === 'login') {
            subtitle.textContent = 'Access your class monitor portal';
        } else {
            subtitle.textContent = 'Create a new class monitor account';
        }
        toggleMon.classList.add('active');
        toggleTeach.classList.remove('active');
        toggleMon.setAttribute('aria-selected', 'true');
        toggleTeach.setAttribute('aria-selected', 'false');
    }
    
    // Clear forms when switching tabs
    document.getElementById('login-form').reset();
    document.getElementById('register-form').reset();
}

function toggleAuthMode(isLogin) {
    authMode = isLogin ? 'login' : 'register';
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const subtitle = document.getElementById('portal-subtitle');
    const role = document.getElementById('login-role').value;

    if (isLogin) {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
        subtitle.textContent = role === 'teacher' ? 
            'Access the administrator teacher portal' : 
            'Access your class monitor portal';
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
        subtitle.textContent = role === 'teacher' ? 
            'Create a new administrator teacher account' : 
            'Create a new class monitor account';
    }
}

function handleLogin(event) {
    event.preventDefault();
    const role = document.getElementById('login-role').value;
    const usernameInput = document.getElementById('username').value.trim().toLowerCase();
    const passwordInput = document.getElementById('password').value;

    const registeredUsers = DB.get('registeredUsers', []);
    const allUsers = [...USERS, ...registeredUsers];

    const user = allUsers.find(u => u.username.toLowerCase() === usernameInput && u.password === passwordInput && u.role === role);

    if (user) {
        DB.save('currentUser', user);
        showToast(`Welcome back, ${user.name}!`, 'success');
        renderAppForSession();
    } else {
        showToast('Invalid credentials or selected incorrect portal.', 'error');
    }
}

function handleRegister(event) {
    event.preventDefault();
    const role = document.getElementById('register-role').value;
    const name = document.getElementById('reg-name').value.trim();
    const username = document.getElementById('reg-username').value.trim();
    const password = document.getElementById('reg-password').value;
    const branch = document.getElementById('reg-branch').value;
    const year = document.getElementById('reg-year').value;

    if (!name || !username || !password || !branch || !year) {
        showToast('Please fill all registration fields.', 'error');
        return;
    }

    const registeredUsers = DB.get('registeredUsers', []);
    const usernameLower = username.toLowerCase();
    const userExists = USERS.some(u => u.username.toLowerCase() === usernameLower) || 
                       registeredUsers.some(u => u.username.toLowerCase() === usernameLower);

    if (userExists) {
        showToast('Username already taken. Please choose another.', 'error');
        return;
    }

    const newUser = {
        username,
        password,
        role,
        name,
        branch,
        year
    };

    registeredUsers.push(newUser);
    DB.save('registeredUsers', registeredUsers);

    // If Monitor registered, make sure their class is added to the system classes list
    if (role === 'monitor') {
        const classId = `${branch.toLowerCase().replace(/[^a-z0-9]/g, '_')}-${year.toLowerCase().replace(' ', '_')}`;
        const className = `${branch} - ${year}`;
        const classes = DB.get('classes');
        if (!classes.some(c => c.id === classId)) {
            classes.push({ id: classId, name: className });
            DB.save('classes', classes);
        }
    }

    showToast('Registration successful! You can now log in.', 'success');
    
    document.getElementById('register-form').reset();
    document.getElementById('username').value = username;
    toggleAuthMode(true);
}

function logout() {
    DB.save('currentUser', null);
    showToast('Logged out successfully.');
    renderAppForSession();
}

function renderAppForSession() {
    const user = DB.get('currentUser', null);
    
    // Hide all main containers
    document.getElementById('login-view').style.display = 'none';
    document.getElementById('monitor-dashboard').classList.remove('active');
    document.getElementById('teacher-dashboard').classList.remove('active');

    if (!user) {
        // No session, show login
        document.getElementById('login-view').style.display = 'block';
        switchLoginPortal('monitor'); // Default
    } else if (user.role === 'monitor') {
        document.getElementById('monitor-dashboard').classList.add('active');
        document.getElementById('monitor-display-name').textContent = user.name;
        initializeMonitorDashboard();
    } else if (user.role === 'teacher') {
        document.getElementById('teacher-dashboard').classList.add('active');
        document.getElementById('teacher-display-name').textContent = user.name;
        initializeTeacherDashboard();
    }
}

// ================= MONITOR DASHBOARD LOGIC =================

let monitorActiveTab = 'take-attendance';

function switchMonitorTab(tabId) {
    monitorActiveTab = tabId;
    
    // Toggle Nav Buttons
    const navItems = document.querySelectorAll('#monitor-dashboard .nav-item');
    navItems.forEach(item => item.classList.remove('active'));
    
    // Find item based on onclick function content
    const activeBtn = Array.from(navItems).find(btn => btn.getAttribute('onclick').includes(tabId));
    if (activeBtn) activeBtn.classList.add('active');

    // Toggle Content Sections
    const tabs = document.querySelectorAll('#monitor-dashboard .tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));
    
    document.getElementById(`tab-${tabId}`).classList.add('active');

    // Refresh content for tabs
    if (tabId === 'take-attendance') {
        loadClassDropdowns();
        loadStudentsForAttendance();
    } else if (tabId === 'add-student') {
        loadClassDropdowns();
        loadStudentDirectory();
    } else if (tabId === 'share-records') {
        loadMonitorSharedLogs();
    }
}

function loadClassDropdowns() {
    const user = DB.get('currentUser');
    const classes = DB.get('classes');
    
    let monitorClassId = '';
    if (user && user.role === 'monitor') {
        monitorClassId = `${user.branch.toLowerCase().replace(/[^a-z0-9]/g, '_')}-${user.year.toLowerCase().replace(' ', '_')}`;
        
        // Auto register monitor's class if it doesn't exist
        const className = `${user.branch} - ${user.year}`;
        if (!classes.some(c => c.id === monitorClassId)) {
            classes.push({ id: monitorClassId, name: className });
            DB.save('classes', classes);
        }
    }

    // Set for Attendance Form
    const attClassSelect = document.getElementById('att-class');
    if (attClassSelect) {
        if (monitorClassId) {
            attClassSelect.innerHTML = `<option value="${monitorClassId}">${user.branch} - ${user.year}</option>`;
            attClassSelect.value = monitorClassId;
        } else {
            attClassSelect.innerHTML = classes.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
        }
    }

    // Set for Student Form
    const studClassSelect = document.getElementById('stud-class');
    if (studClassSelect) {
        if (monitorClassId) {
            studClassSelect.innerHTML = `<option value="${monitorClassId}">${user.branch} - ${user.year}</option>`;
            studClassSelect.value = monitorClassId;
        } else {
            studClassSelect.innerHTML = classes.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
        }
    }

    // Set for Student Directory Filter
    const filterClassSelect = document.getElementById('directory-class-filter');
    if (filterClassSelect) {
        if (monitorClassId) {
            filterClassSelect.innerHTML = `<option value="${monitorClassId}">${user.branch} - ${user.year}</option>`;
            filterClassSelect.value = monitorClassId;
        } else {
            filterClassSelect.innerHTML = classes.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
        }
    }
}

function loadStudentsForAttendance() {
    const classId = document.getElementById('att-class').value;
    if (!classId) return;

    const students = DB.get('students').filter(s => s.classId === classId);
    const container = document.getElementById('attendance-checklist-container');
    const rosterCount = document.getElementById('roster-count');

    rosterCount.textContent = `${students.length} Student${students.length !== 1 ? 's' : ''}`;

    if (students.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">👥</div>
                <p>No students enrolled in this class yet. Add students in the 'Add Student' tab.</p>
            </div>
        `;
        return;
    }

    container.innerHTML = students.map(student => `
        <div class="attendance-row" data-student-id="${student.id}">
            <div class="student-info-col">
                <span class="student-name-txt">${student.name}</span>
                <span class="student-phone-txt">
                    <span>📞 ${student.phone}</span>
                    <span>💬 ${student.whatsapp}</span>
                </span>
            </div>
            <div class="attendance-pills" role="radiogroup" aria-label="Attendance for ${student.name}">
                <button type="button" class="pill-btn present-pill active" onclick="setAttendanceStatus('${student.id}', 'present')" id="pill-p-${student.id}">
                    P
                </button>
                <button type="button" class="pill-btn absent-pill" onclick="setAttendanceStatus('${student.id}', 'absent')" id="pill-a-${student.id}">
                    A
                </button>
            </div>
        </div>
    `).join('');
}

// Keep track of checklist status
const currentChecklistState = {};

function setAttendanceStatus(studentId, status) {
    const presentPill = document.getElementById(`pill-p-${studentId}`);
    const absentPill = document.getElementById(`pill-a-${studentId}`);

    if (status === 'present') {
        presentPill.classList.add('active');
        absentPill.classList.remove('active');
        currentChecklistState[studentId] = 'present';
    } else {
        absentPill.classList.add('active');
        presentPill.classList.remove('active');
        currentChecklistState[studentId] = 'absent';
    }
}

function submitAttendance(event) {
    event.preventDefault();
    const classId = document.getElementById('att-class').value;
    const attDate = document.getElementById('att-date').value;
    const startTime = document.getElementById('att-start-time').value;
    const endTime = document.getElementById('att-end-time').value;
    const subject = document.getElementById('att-subject').value.trim();
    const topic = document.getElementById('att-topic').value.trim();
    const user = DB.get('currentUser');

    if (!classId || !attDate || !startTime || !endTime || !subject || !topic) {
        showToast('Please fill all attendance details.', 'error');
        return;
    }

    const students = DB.get('students').filter(s => s.classId === classId);
    if (students.length === 0) {
        showToast('Cannot submit attendance for a class with zero students.', 'error');
        return;
    }

    // Compile records map
    const records = {};
    students.forEach(student => {
        // Read from elements or default to present if not set
        const absentActive = document.getElementById(`pill-a-${student.id}`).classList.contains('active');
        records[student.id] = absentActive ? 'absent' : 'present';
    });

    const newLog = {
        id: 'log-' + Date.now(),
        classId,
        date: attDate,
        startTime,
        endTime,
        subject,
        topic,
        records,
        submittedBy: user.username
    };

    const attendanceLogs = DB.get('attendance');
    attendanceLogs.push(newLog);
    DB.save('attendance', attendanceLogs);

    showToast('Attendance logged successfully!', 'success');
    
    // Reset Form fields & reload list
    document.getElementById('att-subject').value = '';
    document.getElementById('att-topic').value = '';
    loadStudentsForAttendance();
}

function addStudent(event) {
    event.preventDefault();
    
    const classId = document.getElementById('stud-class').value;
    const name = document.getElementById('stud-name').value.trim();
    const phone = document.getElementById('stud-phone').value.trim();
    const whatsapp = document.getElementById('stud-whatsapp').value.trim();

    if (!classId || !name || !phone || !whatsapp) {
        showToast('Please fill all student details.', 'error');
        return;
    }

    const students = DB.get('students');
    const newStudent = {
        id: 'stud-' + Date.now(),
        name,
        classId,
        phone,
        whatsapp
    };

    students.push(newStudent);
    DB.save('students', students);

    showToast(`Added ${name} successfully!`, 'success');
    
    // Reset inputs
    document.getElementById('stud-name').value = '';
    document.getElementById('stud-phone').value = '';
    document.getElementById('stud-whatsapp').value = '';

    loadStudentDirectory();
}

function loadStudentDirectory() {
    const classId = document.getElementById('directory-class-filter').value;
    const tbody = document.getElementById('student-directory-tbody');
    
    if (!classId) {
        tbody.innerHTML = '<tr><td colspan="4" class="empty-state">No class selected</td></tr>';
        return;
    }

    const students = DB.get('students').filter(s => s.classId === classId);

    if (students.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="empty-state">No students found in this class</td></tr>';
        return;
    }

    tbody.innerHTML = students.map(student => {
        const alertsEnabled = student.alertsEnabled !== false;
        const alertsBtn = alertsEnabled ? 
            `<button onclick="toggleStudentAlerts('${student.id}')" class="action-icon-btn" style="background: var(--color-present-glow); color: var(--color-present); border: 1px solid rgba(16,185,129,0.3); font-size:0.75rem; padding: 4px 8px; cursor:pointer; border-radius: var(--border-radius-sm);">🔔 Active</button>` : 
            `<button onclick="toggleStudentAlerts('${student.id}')" class="action-icon-btn" style="background: var(--color-absent-glow); color: var(--color-absent); border: 1px solid rgba(244,63,94,0.3); font-size:0.75rem; padding: 4px 8px; cursor:pointer; border-radius: var(--border-radius-sm);">🔕 Muted</button>`;
        return `
            <tr>
                <td style="font-weight:600;">${student.name}</td>
                <td>📞 ${student.phone}</td>
                <td>💬 ${student.whatsapp}</td>
                <td>${alertsBtn}</td>
            </tr>
        `;
    }).join('');
}

function loadMonitorSharedLogs() {
    const user = DB.get('currentUser');
    const logs = DB.get('attendance').filter(log => log.submittedBy === user.username);
    const classes = DB.get('classes');
    const tbody = document.getElementById('monitor-logs-tbody');

    if (logs.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state">You have not submitted any logs yet</td></tr>';
        return;
    }

    // Sort logs descending (newest first) by date and time
    logs.sort((a,b) => b.date.localeCompare(a.date) || (b.startTime || b.lectureTime || '').localeCompare(a.startTime || a.lectureTime || ''));

    tbody.innerHTML = logs.map(log => {
        const cls = classes.find(c => c.id === log.classId);
        const className = cls ? cls.name : 'Unknown';
        
        // Count present/absent
        let present = 0, absent = 0;
        Object.values(log.records).forEach(status => {
            if (status === 'present') present++;
            else absent++;
        });

        const timeStr = log.startTime ? `${log.startTime} - ${log.endTime}` : (log.lectureTime || 'N/A');

        return `
            <tr>
                <td>${log.date}</td>
                <td style="font-weight:600;">${className}</td>
                <td><strong>${log.subject || 'N/A'}</strong><br><span style="font-size:0.85rem; color:var(--text-secondary);">${log.topic || 'N/A'}</span></td>
                <td>${timeStr}</td>
                <td>
                    <span class="badge-present">${present} P</span>
                    <span class="badge-absent">${absent} A</span>
                </td>
                <td>
                    <button class="action-icon-btn share-btn-secondary" onclick="shareRecordToTeacher('${log.id}')">
                        Copy Report 📋
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function shareRecordToTeacher(logId) {
    const log = DB.get('attendance').find(l => l.id === logId);
    if (!log) return;

    const classes = DB.get('classes');
    const studentsObj = DB.get('students');
    const className = (classes.find(c => c.id === log.classId) || {}).name || 'Unknown Class';

    const presentList = [];
    const absentList = [];

    Object.entries(log.records).forEach(([studentId, status]) => {
        const student = studentsObj.find(s => s.id === studentId);
        if (student) {
            if (status === 'present') {
                presentList.push(student.name);
            } else {
                absentList.push(student.name);
            }
        }
    });

    const timeStr = log.startTime ? `${log.startTime} to ${log.endTime}` : (log.lectureTime || 'N/A');

    const reportText = `*AttendEase Attendance Report*
🏫 Class: ${className}
📅 Date: ${log.date}
🕒 Lecture Time: ${timeStr}
📚 Subject: ${log.subject || 'N/A'}
📖 Topic Covered: ${log.topic || 'N/A'}
--------------------------------
✅ Present (${presentList.length}): ${presentList.length > 0 ? presentList.join(', ') : 'None'}
❌ Absent (${absentList.length}): ${absentList.length > 0 ? absentList.join(', ') : 'None'}
--------------------------------
Report generated by Class Monitor via AttendEase.`;

    navigator.clipboard.writeText(reportText).then(() => {
        showToast('Attendance report text copied to clipboard! Ready to share.', 'success');
    }).catch(err => {
        console.error('Could not copy text: ', err);
        showToast('Clipboard block! Copy manually.', 'error');
    });
}

function initializeMonitorDashboard() {
    switchMonitorTab('take-attendance');
    
    // Set date and times fields
    const now = new Date();
    const dateField = document.getElementById('att-date');
    const startTimeField = document.getElementById('att-start-time');
    const endTimeField = document.getElementById('att-end-time');

    if (dateField) {
        dateField.value = now.toISOString().split('T')[0];
    }
    
    if (startTimeField) {
        startTimeField.value = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    }
    
    if (endTimeField) {
        const endHour = (now.getHours() + 1) % 24;
        endTimeField.value = `${String(endHour).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    }
}


// ================= TEACHER DASHBOARD LOGIC =================

let teacherActiveTab = 'overview';

function switchTeacherTab(tabId) {
    teacherActiveTab = tabId;
    
    // Toggle Nav Buttons
    const navItems = document.querySelectorAll('#teacher-dashboard .nav-item');
    navItems.forEach(item => item.classList.remove('active'));
    
    const activeBtn = Array.from(navItems).find(btn => btn.getAttribute('onclick').includes(tabId));
    if (activeBtn) activeBtn.classList.add('active');

    // Toggle Content Sections
    const tabs = document.querySelectorAll('#teacher-dashboard .tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));
    
    document.getElementById(`tab-teacher-${tabId}`).classList.add('active');

    // Refresh contents
    if (tabId === 'overview') {
        loadTeacherOverview();
    } else if (tabId === 'alerts') {
        loadTeacherAlerts();
    } else if (tabId === 'logs') {
        setupTeacherLogsTab();
    } else if (tabId === 'roster') {
        setupTeacherRosterTab();
    }
}

function loadTeacherOverview() {
    const classes = DB.get('classes');
    const students = DB.get('students');
    const logs = DB.get('attendance');
    const alertData = calculateAbsenteeAlerts();

    // Set numbers
    document.getElementById('metric-classes').textContent = classes.length;
    document.getElementById('metric-students').textContent = students.length;
    document.getElementById('metric-alerts').textContent = alertData.length;

    // Red pill notification sync
    const pillCount = document.getElementById('alert-pill-count');
    if (alertData.length > 0) {
        pillCount.textContent = alertData.length;
        pillCount.style.display = 'inline-block';
    } else {
        pillCount.style.display = 'none';
    }

    // Overall attendance rate
    let totalRecords = 0;
    let presentRecords = 0;
    logs.forEach(log => {
        Object.values(log.records).forEach(status => {
            totalRecords++;
            if (status === 'present') presentRecords++;
        });
    });
    
    const overallRate = totalRecords > 0 ? Math.round((presentRecords / totalRecords) * 100) : 100;
    document.getElementById('metric-rate').textContent = `${overallRate}%`;

    // Render Class statistics charts
    const chartContainer = document.getElementById('class-analytics-chart');
    if (classes.length === 0) {
        chartContainer.innerHTML = '<p class="empty-state">No class data found.</p>';
    } else {
        chartContainer.innerHTML = classes.map(c => {
            // Calculate rate for this class
            let classTotal = 0;
            let classPresent = 0;
            const classLogs = logs.filter(log => log.classId === c.id);

            classLogs.forEach(log => {
                Object.values(log.records).forEach(status => {
                    classTotal++;
                    if (status === 'present') classPresent++;
                });
            });

            const rate = classTotal > 0 ? Math.round((classPresent / classTotal) * 100) : 100;
            
            return `
                <div class="chart-bar-item">
                    <span class="chart-bar-label" title="${c.name}">${c.name}</span>
                    <div class="chart-bar-wrapper">
                        <div class="chart-bar-fill" style="width: ${rate}%;"></div>
                    </div>
                    <span class="chart-bar-val">${rate}%</span>
                </div>
            `;
        }).join('');
    }

    // Recent submissions Table
    const recentTbody = document.getElementById('teacher-recent-logs-tbody');
    // Sort logs descending (newest first) by date and time, and slice first 5
    const recentLogs = [...logs].sort((a,b) => b.date.localeCompare(a.date) || (b.startTime || b.lectureTime || '').localeCompare(a.startTime || a.lectureTime || '')).slice(0, 5);

    if (recentLogs.length === 0) {
        recentTbody.innerHTML = '<tr><td colspan="6" class="empty-state">No attendance records stored in database</td></tr>';
        return;
    }

    recentTbody.innerHTML = recentLogs.map(log => {
        const cls = classes.find(c => c.id === log.classId);
        const className = cls ? cls.name : 'Unknown';
        
        let present = 0, total = 0;
        Object.values(log.records).forEach(status => {
            total++;
            if (status === 'present') present++;
        });
        const rate = total > 0 ? Math.round((present / total) * 100) : 100;

        return `
            <tr>
                <td>${log.date}</td>
                <td style="font-weight:600;">${className}</td>
                <td><strong>${log.subject || 'N/A'}</strong><br><span style="font-size:0.85rem; color:var(--text-secondary);">${log.topic || 'N/A'}</span></td>
                <td>${log.startTime ? log.startTime + ' - ' + log.endTime : (log.lectureTime || 'N/A')}</td>
                <td>
                    <span class="badge-present" style="font-size:0.8rem;">${rate}% Rate</span>
                </td>
                <td>@${log.submittedBy}</td>
            </tr>
        `;
    }).join('');
}

/*
 * Consecutive Absence calculation algorithm:
 * 1. Gather all class logs and sort chronologically.
 * 2. Loop backwards from the latest log.
 * 3. Track sequential 'absent' states for each student in the class.
 * 4. Return students whose current active absent streak >= 2.
 */
function calculateAbsenteeAlerts() {
    const classes = DB.get('classes');
    const students = DB.get('students');
    const logs = DB.get('attendance');
    const alerts = [];

    classes.forEach(cls => {
        const classStudents = students.filter(s => s.classId === cls.id);
        // Get logs for this class, sorted chronologically (oldest to newest)
        const classLogs = logs.filter(log => log.classId === cls.id)
                              .sort((a,b) => a.date.localeCompare(b.date) || (a.startTime || a.lectureTime || '').localeCompare(b.startTime || b.lectureTime || ''));

        if (classLogs.length < 2) return; // Need at least 2 logs to have 2 consecutive absences

        classStudents.forEach(student => {
            if (student.alertsEnabled === false) return; // Skip students with disabled alerts
            let consecutiveAbsences = 0;
            let lastAbsentLog = null;

            // Go backwards from newest log
            for (let i = classLogs.length - 1; i >= 0; i--) {
                const log = classLogs[i];
                const status = log.records[student.id];

                if (status === 'absent') {
                    consecutiveAbsences++;
                    if (!lastAbsentLog) {
                        lastAbsentLog = log;
                    }
                } else if (status === 'present') {
                    // Streak is broken
                    break;
                }
                // If status is undefined (student wasn't in roster at that time), ignore or skip
            }

            if (consecutiveAbsences >= 2) {
                alerts.push({
                    student,
                    className: cls.name,
                    consecutiveAbsences,
                    lastTopic: lastAbsentLog ? lastAbsentLog.topic : 'N/A',
                    lastDate: lastAbsentLog ? lastAbsentLog.date : 'N/A'
                });
            }
        });
    });

    return alerts;
}

function loadTeacherAlerts() {
    const alerts = calculateAbsenteeAlerts();
    const tbody = document.getElementById('absentee-alerts-tbody');

    if (alerts.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="empty-state" style="padding: 50px;">
                    <div class="empty-state-icon" style="color:var(--color-present);">✓</div>
                    <p style="color:var(--text-primary); font-weight:600; font-size:1.1rem; margin-bottom:4px;">Roster Healthy</p>
                    <p style="font-size:0.85rem;">No students are currently marked absent for 2 or more consecutive classes.</p>
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = alerts.map(alert => {
        const studentName = alert.student.name;
        const msgText = `Hello, this is ${DB.get('currentUser').name}. I noticed that ${studentName} has been absent for ${alert.consecutiveAbsences} consecutive classes in ${alert.className} (Last absent: ${alert.lastDate} during topic "${alert.lastTopic}"). Please update us on the reason. Thank you.`;
        const waLink = `https://wa.me/${alert.student.whatsapp.replace('+', '')}?text=${encodeURIComponent(msgText)}`;
        
        return `
            <tr class="alert-row">
                <td style="font-weight:700; color:#fb7185;">⚠️ ${studentName}</td>
                <td>${alert.className}</td>
                <td>
                    <span class="badge-absent" style="font-size:0.8rem; padding: 4px 10px; font-weight:700;">
                        ${alert.consecutiveAbsences} Classes Streak
                    </span>
                </td>
                <td>${alert.lastDate} <br><span style="font-size:0.8rem; color:var(--text-secondary);">${alert.lastTopic}</span></td>
                <td>
                    <div class="action-buttons-group">
                        <a href="tel:${alert.student.phone}" class="action-icon-btn call-btn">
                            📞 Call Student
                        </a>
                        <a href="${waLink}" target="_blank" rel="noopener" class="action-icon-btn wa-btn">
                            💬 Message WhatsApp
                        </a>
                        <button onclick="toggleStudentAlerts('${alert.student.id}')" class="action-icon-btn" style="background: rgba(244,63,94,0.1); color: #fb7185; border: 1px solid rgba(244,63,94,0.3); cursor: pointer; padding: 6px 12px; font-size: 0.85rem; border-radius: var(--border-radius-sm); font-weight: 500;">
                            🔕 Mute Alert
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

function setupTeacherLogsTab() {
    // Fill Classes filter dropdown
    const classes = DB.get('classes');
    const filterClass = document.getElementById('log-filter-class');
    
    // Save current selection to restore
    const selected = filterClass.value;
    filterClass.innerHTML = '<option value="all">All Classes</option>' + 
        classes.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    filterClass.value = selected;

    filterAttendanceLogs();
}

function filterAttendanceLogs() {
    const classId = document.getElementById('log-filter-class').value;
    const dateVal = document.getElementById('log-filter-date').value;
    const logs = DB.get('attendance');
    const classes = DB.get('classes');
    const tbody = document.getElementById('all-logs-tbody');

    let filtered = [...logs];

    if (classId !== 'all') {
        filtered = filtered.filter(l => l.classId === classId);
    }
    if (dateVal) {
        filtered = filtered.filter(l => l.date === dateVal);
    }

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state">No matching logs found in system</td></tr>';
        return;
    }

    // Sort newest first by date and time
    filtered.sort((a,b) => b.date.localeCompare(a.date) || (b.startTime || b.lectureTime || '').localeCompare(a.startTime || a.lectureTime || ''));

    tbody.innerHTML = filtered.map(log => {
        const cls = classes.find(c => c.id === log.classId);
        const className = cls ? cls.name : 'Unknown';

        let present = 0, total = 0;
        Object.values(log.records).forEach(status => {
            total++;
            if (status === 'present') present++;
        });
        const rate = total > 0 ? Math.round((present / total) * 100) : 100;

        const timeStr = log.startTime ? `${log.startTime} - ${log.endTime}` : (log.lectureTime || 'N/A');

        return `
            <tr>
                <td>${log.date}</td>
                <td style="font-weight:600;">${className}</td>
                <td>${timeStr}</td>
                <td><strong>${log.subject || 'N/A'}</strong><br><span style="font-size:0.85rem; color:var(--text-secondary);">${log.topic || 'N/A'}</span></td>
                <td>
                    <span class="badge-present">${rate}% Rate</span>
                    <span class="text-secondary" style="font-size:0.8rem; margin-left:5px;">(${present}/${total})</span>
                </td>
                <td>@${log.submittedBy}</td>
                <td>
                    <button class="action-icon-btn share-btn-secondary" onclick="viewLogDetails('${log.id}')">
                        Inspect 🔍
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function clearLogFilters() {
    document.getElementById('log-filter-class').value = 'all';
    document.getElementById('log-filter-date').value = '';
    filterAttendanceLogs();
}

function viewLogDetails(logId) {
    const log = DB.get('attendance').find(l => l.id === logId);
    if (!log) return;

    const classes = DB.get('classes');
    const className = (classes.find(c => c.id === log.classId) || {}).name || 'Unknown Class';
    const students = DB.get('students');

    const timeStr = log.startTime ? `${log.startTime} to ${log.endTime}` : (log.lectureTime || 'N/A');

    document.getElementById('modal-lecture-title').textContent = 'Lecture Attendance Details';
    document.getElementById('modal-lecture-class').textContent = className;
    document.getElementById('modal-lecture-subject').textContent = log.subject || 'N/A';
    document.getElementById('modal-lecture-topic').textContent = log.topic || 'N/A';
    document.getElementById('modal-lecture-datetime').textContent = `${log.date} from ${timeStr}`;

    const modalRosterTbody = document.getElementById('modal-roster-tbody');
    modalRosterTbody.innerHTML = '';

    // Populate students present or absent
    Object.entries(log.records).forEach(([studentId, status]) => {
        const student = students.find(s => s.id === studentId);
        if (student) {
            const badge = status === 'present' ? 
                '<span class="badge-present">Present</span>' : 
                '<span class="badge-absent">Absent</span>';
            
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="font-weight:600;">${student.name}</td>
                <td>${badge}</td>
            `;
            modalRosterTbody.appendChild(tr);
        }
    });

    document.getElementById('attendance-details-modal').classList.add('active');
}

function closeDetailsModal() {
    document.getElementById('attendance-details-modal').classList.remove('active');
}

function setupTeacherRosterTab() {
    const classes = DB.get('classes');
    const filterClass = document.getElementById('roster-filter-class');
    
    const selected = filterClass.value;
    filterClass.innerHTML = '<option value="all">All Classes</option>' + 
        classes.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    filterClass.value = selected;

    filterRosterTable();
}

function filterRosterTable() {
    const searchQuery = document.getElementById('roster-search').value.toLowerCase().trim();
    const classId = document.getElementById('roster-filter-class').value;
    
    const students = DB.get('students');
    const classes = DB.get('classes');
    const logs = DB.get('attendance');
    const tbody = document.getElementById('roster-tbody');

    let filtered = [...students];

    if (classId !== 'all') {
        filtered = filtered.filter(s => s.classId === classId);
    }
    if (searchQuery) {
        filtered = filtered.filter(s => s.name.toLowerCase().includes(searchQuery));
    }

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state">No students match the search criteria</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map(student => {
        const cls = classes.find(c => c.id === student.classId);
        const className = cls ? cls.name : 'Unknown';

        // Calculate student personal attendance rate
        let totalClasses = 0;
        let presentCount = 0;

        logs.forEach(log => {
            if (log.classId === student.classId && log.records[student.id] !== undefined) {
                totalClasses++;
                if (log.records[student.id] === 'present') {
                    presentCount++;
                }
            }
        });

        const rate = totalClasses > 0 ? Math.round((presentCount / totalClasses) * 100) : 100;
        const rateClass = rate < 75 ? 'badge-absent' : 'badge-present';
        const alertsEnabled = student.alertsEnabled !== false;
        const alertsBtn = alertsEnabled ? 
            `<button onclick="toggleStudentAlerts('${student.id}')" class="action-icon-btn" style="background: var(--color-present-glow); color: var(--color-present); border: 1px solid rgba(16,185,129,0.3); font-size:0.75rem; padding: 4px 8px; cursor:pointer; border-radius: var(--border-radius-sm);">🔔 Active</button>` : 
            `<button onclick="toggleStudentAlerts('${student.id}')" class="action-icon-btn" style="background: var(--color-absent-glow); color: var(--color-absent); border: 1px solid rgba(244,63,94,0.3); font-size:0.75rem; padding: 4px 8px; cursor:pointer; border-radius: var(--border-radius-sm);">🔕 Muted</button>`;

        return `
            <tr>
                <td style="font-weight:600;">${student.name}</td>
                <td>${className}</td>
                <td>📞 ${student.phone}</td>
                <td>💬 ${student.whatsapp}</td>
                <td>
                    <span class="${rateClass}" style="font-size:0.8rem;">${rate}%</span>
                    <span style="font-size:0.75rem; color:var(--text-muted);"> (${presentCount}/${totalClasses})</span>
                </td>
                <td>${alertsBtn}</td>
                <td>
                    <button class="action-icon-btn logout-btn" style="background:rgba(244,63,94,0.05); border:1px solid rgba(244,63,94,0.15); padding: 4px 8px; font-size:0.75rem;" onclick="removeStudent('${student.id}')">
                        Remove 🗑️
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function removeStudent(studentId) {
    const students = DB.get('students');
    const student = students.find(s => s.id === studentId);
    if (!student) return;

    if (confirm(`Are you sure you want to delete ${student.name}'s profile? Historical logs will preserve the attendance record but the profile will be cleared.`)) {
        const updated = students.filter(s => s.id !== studentId);
        DB.save('students', updated);
        showToast('Student profile deleted from system roster.', 'info');
        filterRosterTable();
    }
}

function toggleStudentAlerts(studentId) {
    const students = DB.get('students');
    const student = students.find(s => s.id === studentId);
    if (!student) return;

    student.alertsEnabled = student.alertsEnabled === false ? true : false;
    DB.save('students', students);

    showToast(`Alerts for ${student.name} ${student.alertsEnabled ? 'enabled' : 'muted (student on leave)'}.`, 'success');

    // Refresh dashboards/tables based on role
    const user = DB.get('currentUser');
    if (user) {
        if (user.role === 'teacher') {
            loadTeacherOverview();
            loadTeacherAlerts();
            filterRosterTable();
        } else if (user.role === 'monitor') {
            loadStudentDirectory();
        }
    }
}

// Add Student Modals (Teacher specific)
function openAddStudentModal() {
    const classes = DB.get('classes');
    const select = document.getElementById('modal-stud-class');
    select.innerHTML = classes.map(c => `<option value="${c.id}">${c.name}</option>`).join('');

    document.getElementById('add-student-modal').classList.add('active');
}

function closeAddStudentModal() {
    document.getElementById('add-student-modal').classList.remove('active');
    document.getElementById('modal-add-student-form').reset();
}

function handleAddStudentModalSubmit(event) {
    event.preventDefault();
    const classId = document.getElementById('modal-stud-class').value;
    const name = document.getElementById('modal-stud-name').value.trim();
    const phone = document.getElementById('modal-stud-phone').value.trim();
    const whatsapp = document.getElementById('modal-stud-whatsapp').value.trim();

    if (!classId || !name || !phone || !whatsapp) {
        showToast('Please fill all fields.', 'error');
        return;
    }

    const students = DB.get('students');
    const newStudent = {
        id: 'stud-' + Date.now(),
        name,
        classId,
        phone,
        whatsapp
    };

    students.push(newStudent);
    DB.save('students', students);

    showToast(`Added ${name} to roster database!`, 'success');
    closeAddStudentModal();
    filterRosterTable();
}

// Export database directly to CSV file offline
function exportDatabaseToCSV() {
    const logs = DB.get('attendance');
    const students = DB.get('students');
    const classes = DB.get('classes');

    if (logs.length === 0) {
        showToast('Database contains no attendance records to export.', 'error');
        return;
    }

    // Header
    let csvContent = 'Date,Class,Start Time,End Time,Subject,Topic Covered,Student Name,Attendance Status,Phone Number,WhatsApp Number,Logged By\r\n';

    logs.forEach(log => {
        const cls = classes.find(c => c.id === log.classId);
        const className = cls ? cls.name : 'Unknown';

        Object.entries(log.records).forEach(([studentId, status]) => {
            const student = students.find(s => s.id === studentId);
            const studentName = student ? student.name : 'Unknown Student';
            const phone = student ? student.phone : 'N/A';
            const whatsapp = student ? student.whatsapp : 'N/A';

            // Clean strings for CSV
            const subjectClean = (log.subject || 'N/A').replace(/"/g, '""');
            const topicClean = (log.topic || 'N/A').replace(/"/g, '""');
            const nameClean = studentName.replace(/"/g, '""');

            const sTime = log.startTime || log.lectureTime || 'N/A';
            const eTime = log.endTime || 'N/A';

            csvContent += `"${log.date}","${className}","${sTime}","${eTime}","${subjectClean}","${topicClean}","${nameClean}","${status.toUpperCase()}","${phone}","${whatsapp}","${log.submittedBy}"\r\n`;
        });
    });

    // Create file trigger download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `attendease_attendance_db_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showToast('Database CSV compiled and downloaded!', 'success');
}

function initializeTeacherDashboard() {
    switchTeacherTab('overview');
}


window.addEventListener('DOMContentLoaded', () => {
    initializeDatabase();
    renderAppForSession();

    // Register Service Worker for PWA
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('./sw.js')
            .then(reg => console.log('Service Worker registered successfully.', reg))
            .catch(err => console.log('Service Worker registration failed.', err));
    }
});
